const cartas= document.querySelectorAll('.cartas');
let cartavirada= false;
let carta1;
let carta2;
let a=0;
let b=0;
function virarcarta(){
    this.classList.add('flip');

    if(!cartavirada){
        cartavirada=true;
        carta1= this;
        //primeira vez que a carta é clicada
    }else{
        cartavirada=false;
        carta2= this;
        //segunda vez que a carta é clicada

        if(carta1.dataset.carta===carta2.dataset.carta){
            carta1.removeEventListener('click', virarcarta);
            carta2.removeEventListener('click', virarcarta);
            a++;
        }else{
            setTimeout(() => {
            carta1.classList.remove('flip');
            carta2.classList.remove('flip');
        }, 1000);
        b++;
        }
        
    }
}

(function randomizar(){
    cartas.forEach(carta=>{
        let aleatorio= Math.floor(Math.random()*12);
        carta.style.order= aleatorio;
    })
})();


cartas.forEach(carta =>carta.addEventListener('click', virarcarta));