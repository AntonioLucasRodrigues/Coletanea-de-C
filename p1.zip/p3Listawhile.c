#include<stdio.h>

int main(){
	int n, cont=0,con=0;
	float s=0 ;
	scanf("%d", &n);
	while(cont<=n){
		cont++;
		if(con%2==1){
			s+=(4.0/cont);
		}
		else{
			s-=(4.0/cont);
		}
		cont+=2;
	
		}
		printf("%.2f", s);
		return 0;
	}

